# LSTM-implementation
Optimized version of LSTM(Long Short Term Memory) network and it's implementation with improved parameter choices and enhanced layer effiiency.
